#pragma once

namespace protocol::game::sdk {
    class mec_pawn; // Forward declaration of mec_pawn

    struct FStr_ColorLink {
        int Color_2;
        mec_pawn* Mec_5;
    };
}
