#pragma once

namespace radar {
	void draw();
}
