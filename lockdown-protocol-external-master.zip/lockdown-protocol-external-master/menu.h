#pragma once

namespace menu {
	void draw();
}
